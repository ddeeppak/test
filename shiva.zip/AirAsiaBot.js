var botName = "NPS Survey UAT";
var sdk = require("./lib/sdk");
var config = require('./config.json');
var botId = Object.keys(config.credentials);
var jwt = require("jsonwebtoken");

// Require additional modules
const CsvReader = require('./CsvReader.js');
const OutgoingCsv = require('./OutgoingCsv.js');
//const DetractorsMail = require('./DetractorsMail.js');
const Attendees = require('./Attendees.js');

// Register additional bots
sdk.registerBot(CsvReader);
sdk.registerBot(OutgoingCsv);
//sdk.registerBot(DetractorsMail);
sdk.registerBot(Attendees);

module.exports = {
    botId: botId,
    botName: botName,

    on_user_message: function (requestId, data, callback) {
        console.log(new Date(), "ON_USER_MESSAGE: ", data.message);
        return sdk.sendBotMessage(data, callback);
    },
    on_bot_message: function (requestId, data, callback) {
        console.log(new Date(), "ON_BOT_MESSAGE: ", data.message);
        // if (/^dummy\d*$/.test(data.message) || /^loop limit.*/i.test(data.message)) 
        //     {
        //         console.log("skipping");
        //     return;
        //      }
        
        return sdk.sendUserMessage(data, callback);
    },
    on_agent_transfer: function (requestId, data, callback) {
        return callback(null, data);
    },
    on_event: function (requestId, data, callback) {
        console.log("on_event -->  Event : ", data.event);
        return callback(null, data);
    },
    on_alert: function (requestId, data, callback) {
        console.log("on_alert -->  : ", data, data.message);
        return sdk.sendAlertMessage(data, callback);
    },
    on_webhook: async function (requestId, data, componentName, callback) {
        console.log("on_Hook -->  Event : ",componentName);
       if(componentName=="TimeoutHook"){
        setTimeout(function(){ 
            return callback(null);
            
         }, 15000);
       }
    },
    createToken: createToken
};

function createToken(req, res) {
    console.log("Jwt Token Post Call");
    var identity = req.body.identity;
    var clientId = config.credentials.appId;
    var clientSecret = config.credentials.apikey;
    var isAnonymous = req.body.isAnonymous || false;
    var aud = req.body.aud || "https://idproxy.kore.com/authorize";
    var options = {
        iat: Date.now() / 1000,
        exp: Date.now() / 1000 + 864000,
        aud: aud,
        iss: clientId,
        sub: identity,
        isAnonymous: isAnonymous,
    };
    var headers = {};
    var token = jwt.sign(options, clientSecret, headers);
    res.header("Access-Control-Allow-Origin", "*");
    res.send({
        jwt: token,
    });
}
