const schedule = require('node-schedule');
const axios = require('axios');
const config = require("./config");
var botName = "NPS Survey UAT";
var botId = Object.keys(config.credentials);

module.exports = {
    botId: botId,
    botName: botName,
  };

schedule.scheduleJob('59 23 * * *',async function(){
  console.log(new Date(),"Scheduler Activated: Initiating Attendees Counter...")
  try {
    const response = await axios.post(
      'https://bots.kore.ai/chatbot/v2/webhook/st-eb6c9752-1a97-5ea5-b32c-4ff78e4fa3b5',
      {
        message: {
          type: 'text',
          val: 'Attendees counter'
        },
        from: {
          id: 'nps@airasia.com'
        }
      },
      {
        headers: {
          'Authorization': 'bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1jMjIzN2U0OS00ZDk4LTU2OGMtYWJkOS01YjQzOGNhYzIyYjQifQ.6jOH163uPeKfsYRjYvv0MeWy8mkraFhDEIWliHgqHXY',  
          'Content-Type': 'application/json'
        }
      }
    );
    console.log(`Attendees Response`,response.data);
  } catch (error) {
    console.error('Error making API call:', error);
  }
});
