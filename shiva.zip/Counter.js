const axios = require('axios');

const updateCounter = async (sys_Id,updateCountValue) => {
    try {
        const data = JSON.stringify({
            
                "query":{
               "expressions": [
                      {"field": "sys_Id", "operand": "=", "value": sys_Id}
                  ],
                  "operator": "and"
                 },
            "data": {
                "counter": updateCountValue // The new value to update
            }
        });
        let config = {
            method: 'put', // Changed to PUT for update
            maxBodyLength: Infinity,
            url: 'https://bots.kore.ai/api/public/tables/outgoing_counter_UAT',
            headers: {
                'Content-Type': 'application/json',
                'auth': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy05NjgxZmEzNy01MzhkLTVlYWYtODk3MS05NTc2MThkOWFjZGEifQ.8hikz2Zp9UZWI3WbW4DOLzSEzlyQMZJuuz8mA2yYNJA'
            },
            data: data
        };

        const response = await axios.request(config);
    //    console.log(new Date(), JSON.stringify(response.data));         
    } catch (error) {             
        console.log('Error occurred:', error.message); // Log any errors
    }
};

const fetchCounter = async () => {
    try {    
        let currDate = new Date();  
        let value = currDate.getFullYear() + '-' + (currDate.getMonth() + 1).toString().padStart(2, '0') + '-' + currDate.getDate().toString().padStart(2, '0');

        let data = JSON.stringify({
            "query": {
                "expressions": [
                    {
                        "field": "Nps_date",  // Column name for the date search
                        "operand": "=",     // Operand for comparison
                        "value": value      // Replace with the date value you want to search for
                    }
                ],
                "operator": "or"
            }
        });
	console.log("fetchCounter"+data);
        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://bots.kore.ai/api/public/tables/outgoing_counter_UAT/query?sys_limit=10&sys_offset=0',
            headers: {
                'Content-Type': 'application/json',
                'auth': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy05NjgxZmEzNy01MzhkLTVlYWYtODk3MS05NTc2MThkOWFjZGEifQ.8hikz2Zp9UZWI3WbW4DOLzSEzlyQMZJuuz8mA2yYNJA'
            },
            data: data
        };

        const response = await axios.request(config);
        if (response.data && response.data.queryResult) {
            const counter = response.data.queryResult[0]?.counter; // Use optional chaining
            const sys_Id = response.data.queryResult[0]?.sys_Id;
            return { counter, sys_Id };// Return the counter if needed
        }
    } catch (error) {
        console.log('Error occurred:', error.message);
    }
};
const deleteCounter = async () => {
    try {      
        let currDate = new Date();
        let value = currDate.getFullYear() + '-' + (currDate.getMonth() + 1).toString().padStart(2, '0') + '-' + currDate.getDate().toString().padStart(2, '0');

        let data = JSON.stringify({
            
            "query":{
                "expressions": [
                       {"field": "Nps_date", "operand": "=", "value": value}
                   ],
                   "operator": "and"
                  }
          
        });
        let config = {
            method: 'delete',
            maxBodyLength: Infinity,
            url: 'https://bots.kore.ai/api/public/tables/outgoing_counter_UAT',
            headers: {
                'Content-Type': 'application/json',
                'auth': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy05NjgxZmEzNy01MzhkLTVlYWYtODk3MS05NTc2MThkOWFjZGEifQ.8hikz2Zp9UZWI3WbW4DOLzSEzlyQMZJuuz8mA2yYNJA'
            },
            data: data
        };

        const response = await axios.request(config);
        if (response.data && response.data.queryResult) {
            const counter = response.data; // Use optional chaining
            return counter; // Return the counter if needed
        }
    } catch (error) {
        console.log('Error occurred:', error.message);
    }
};
const insertCounter = async (loopCount) => {
    try {
        let currDate = new Date();

        let value = currDate.getFullYear() + '-' + (currDate.getMonth() + 1).toString().padStart(2, '0') + '-' + currDate.getDate().toString().padStart(2, '0');

        const insertData = JSON.stringify({
            "data": {
                "Nps_date": value, 
                "counter": loopCount           
            }
        });
        console.log(new Date(),"this is the couter data",insertData)
        let config = {
            method: 'post', // Use POST to insert data
            maxBodyLength: Infinity,
            url: 'https://bots.kore.ai/api/public/tables/outgoing_counter_UAT',
            headers: {
                'Content-Type': 'application/json',
                'auth': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy05NjgxZmEzNy01MzhkLTVlYWYtODk3MS05NTc2MThkOWFjZGEifQ.8hikz2Zp9UZWI3WbW4DOLzSEzlyQMZJuuz8mA2yYNJA',
                 //'Authorization': 'Basic Og==' // Include the Basic Authorization header
            },
            data: insertData
        };
        const insertResponse = await axios.request(config);
        console.log(new Date(), JSON.stringify(insertResponse.data)); 
    } catch (error) {
        console.log('Error occurred while inserting:', error.message); 
    }
};
const insertupdateCounter = async (updateCountValue) => {
    try { 
        let currDate = new Date();

        let value = currDate.getFullYear() + '-' + (currDate.getMonth() + 1).toString().padStart(2, '0') + '-' + currDate.getDate().toString().padStart(2, '0');

        console.log(new Date(),"insertupdateCounter count started")
        const insertupdateData = JSON.stringify({
            "data": {
                "Nps_date": value, 
                "counter": updateCountValue           
            }
        });
        console.log(new Date(),"this is the couter data",insertupdateData)
        let config = {
            method: 'post', // Use POST to insert data
            maxBodyLength: Infinity,
            url: 'https://bots.kore.ai/api/public/tables/outgoing_counter_UAT',
            headers: {
                'Content-Type': 'application/json',
                'auth': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy05NjgxZmEzNy01MzhkLTVlYWYtODk3MS05NTc2MThkOWFjZGEifQ.8hikz2Zp9UZWI3WbW4DOLzSEzlyQMZJuuz8mA2yYNJA',
                 //'Authorization': 'Basic Og==' // Include the Basic Authorization header
            },
            data: insertupdateData
        };
        const insertResponse = await axios.request(config);
        console.log(new Date(), JSON.stringify(insertResponse.data)); 
    } catch (error) {
        console.log('Error occurred while inserting:', error.message); 
    }
};



module.exports ={ updateCounter,fetchCounter,insertCounter,insertupdateCounter,deleteCounter};



