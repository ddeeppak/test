

// Required modules and services
const fs = require('fs');
const path = require('path');
const schedule = require('node-schedule');
const csv = require('csv-parser');
const shortUrl = require("node-url-shortener");
const config = require("./config");
const sendDataToCleverTap = require('./PushNotificationService.js');
const moveFileAndHandleFailure = require('./FileBackupFailureMailer.js');
const emailService = require('./EmailService.js');
const smsService = require('./SmsService.js');
const SftpClient = require('ssh2-sftp-client');
const { fetchCounter, insertCounter, updateCounter, insertupdateCounter, deleteCounter } = require('./Counter.js');


// Constants and configuration
const MAX_BATCH_SIZE = 50;
var botName = "NPS Survey";
var botId = Object.keys(config.credentials); // Bot ID from config credentials
let languages = {
    "English": "en",
    "Indonesian": "id",
    "Korean": "ko",
    "Japanese": "ja",
    "Vietnamese": "vi",
    "Thai": "th",
    "Malay": "ms",
    "Khmer": "km"
};
var loopCount; // Counter for processed rows

// Export bot details
module.exports = {
    botId: botId,
    botName: botName,
};

// Log bot information on load
console.log("Bot Initialized:", botName, "with ID:", botId);

// Scheduler to run at specified intervals from configuration
let rule = config.schedular_Time.csvReaderSchedule;
schedule.scheduleJob(rule, async function () {
    console.log(new Date(), "Scheduler Activated: Initiating CSV file read from SFTP.");
    try {
        await readCSVFromSFTP();
    } catch (error) {
        console.error(new Date(), 'An error occurred in the scheduled task:', error);
    } finally {
        console.log(new Date(), "Scheduler completed successfully. Awaiting next run...");
    }
});

// Main function to read CSV from SFTP
async function readCSVFromSFTP() {
    const sftp = new SftpClient();
    const configSFTP = {
        host: config.sftp.host,
        port: config.sftp.port,
        username: config.sftp.username,
        password: config.sftp.password,
        algorithms: {
            serverHostKey: ['ssh-dss', 'ssh-rsa'],
            kex: [
                'diffie-hellman-group-exchange-sha256',
                'diffie-hellman-group14-sha1',
                'diffie-hellman-group1-sha1'
            ],
            cipher: [
                'aes128-ctr', 'aes192-ctr', 'aes256-ctr',
                'aes128-gcm', 'aes256-gcm'
            ],
            serverHostKey: ['ssh-rsa', 'ssh-dss']
        }

    };

    try {
        // Connect to SFTP server
        await sftp.connect(configSFTP);
        console.log(new Date(), "Connected to SFTP server.");

        // List files in the specified directory
        const remoteDirectoryPath = config.csvReaderFilePath.readCsvfromSFTPPath;
        const files = await sftp.list(remoteDirectoryPath);
        const csvFiles = files.filter(file => file.name.endsWith('.csv'));
        console.log(new Date(), "CSV files found:", csvFiles.map(file => file.name).join(', '));

        // Process each CSV file
        for (const file of csvFiles) {
            const remoteFilePath = `${remoteDirectoryPath}${file.name}`;
            const buffer = await sftp.get(remoteFilePath);
            const data = buffer.toString();
            const rows = data.split('\n').filter(row => row.trim() !== ''); // Remove empty rows
            const dataRows = rows.slice(1); // Exclude header row
            console.log(new Date(), `Reading CSV File: "${remoteFilePath}" containing ${dataRows.length} rows of data.`);
            const headers = rows[0].split(',').map(header => header.trim());
            var loopCount = 0; // Reset loopCount for each file

            // Process each row
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i].split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/).map(cell => cell.trim());
                const rowValue = row[15];
                let languageCode;

                if (
                    rowValue === "Chinese (Traditional)" ||
                    rowValue === "Chinese (Hong Kong)" ||
                    rowValue === "Chinese (Macau)" ||
                    rowValue === "Chinese (Taiwan)"
                ) {
                    languageCode = "zh_tw";
                } else if (
                    rowValue === "Chinese (Simplified)" ||
                    rowValue === "Chinese (Republic of China)" ||
                    rowValue === "Chinese (Singapore)"
                ) {
                    languageCode = "zh_cn";
                } else {
                    const language = rowValue.split('(')[0].trim();
                    languageCode = languages[language] || "en";
                }

                if (row.length === headers.length) {
                    const obj = {};
                    headers.forEach((header, index) => {
                        obj[header] = row[index];
                    });

                    // Construct URL with encoded parameters
                    const botURL = config.app.url + config.url.botURL;
                    const combinedUrl = `${botURL}&ata=${encodeURIComponent(obj['ata'])}&aoc=${encodeURIComponent(obj['aoc'])}&departureCountry=${encodeURIComponent(obj['departure_country'])}&departureStation=${encodeURIComponent(obj['departure_station'])}&arrivalCountry=${encodeURIComponent(obj['arrival_country'])}&arrivalStation=${encodeURIComponent(obj['arrival_station'])}&flythruFlg=${encodeURIComponent(obj['flythru_flg'])}&pos=${encodeURIComponent(obj['pos'])}&route=${encodeURIComponent(obj['route'])}&paxCount=${encodeURIComponent(obj['pax_count'])}&pnr=${encodeURIComponent(obj['pnr'])}&travellerName=${encodeURIComponent(obj['traveller_name'])}&email=${encodeURIComponent(obj['email'])}&countryCode=${encodeURIComponent(obj['country_code_contact_no'])}&mobile=${encodeURIComponent(obj['mobile'])}&travellerLanguage=${encodeURIComponent(obj['traveller_language'])}&fareType=${encodeURIComponent(obj['fare_type'])}&flightNo=${encodeURIComponent(obj['flight_no'])}&airlineCode=${encodeURIComponent(obj['airline_code'])}&aircraftType=${encodeURIComponent(obj['aircraft_type'])}&aircraftRegNo=${encodeURIComponent(obj['aircraft_reg_no'])}&interactiveLanguage=${encodeURIComponent(languageCode)}`;

                    // Prepare data for CleverTap, Email, and SMS services
                    const dataToCleverTap = {
                        "d": [
                            {
                                "identity": obj["email"],
                                "type": "event",
                                "evtName": "api_aa_npsjourney_successful",
                                "evtData": {
                                    "pnr": obj["pnr"],
                                    "origin": obj["departure_station"],
                                    "destination": obj["arrival_station"],
                                    "redirection_push": config.url.pushBotURL,
                                    "touchPoint": "pj",
                                    "ata": obj["ata"],
                                    "aoc": obj["aoc"],
                                    "departureCountry": obj["departure_country"],
                                    "departureStation": obj["departure_station"],
                                    "arrivalCountry": obj["arrival_country"],
                                    "arrivalStation": obj["arrival_station"],
                                    "flythruFlg": obj["flythru_flg"],
                                    "pos": obj["pos"],
                                    "route": obj["route"],
                                    "paxCount": obj["pax_count"],
                                    "travellerName": obj["traveller_name"],
                                    "email": obj["email"],
                                    "countryCode": obj["country_code_contact_no"],
                                    "mobile": obj["mobile"],
                                    "travellerLanguage": obj["traveller_language"],
                                    "fareType": obj["fare_type"],
                                    "flightNo": obj["flight_no"],
                                    "airlineCode": obj["airline_code"],
                                    "aircraftType": obj["aircraft_type"],
                                    "aircraftRegNo": obj["aircraft_reg_no"],
                                    "interactiveLanguage": languageCode,
                                }
                            }
                        ]
                    };

                    const dataToEmail = JSON.stringify({
                        "records": [{
                            "attributes": { "type": "NPS__c", "referenceId": `ref${i}` },
                            "Type__c": "Post Journey",
                            "Email_Address__c": obj["email"],
                            "Booking_Number__c": obj["pnr"],
                            "Booking_Person_Full_Name__c": obj["traveller_name"],
                            "Departure_Station__c": obj["departure_station"],
                            "Departure_Airport__c": obj["departure_country"],
                            "Arrival_Station__c": obj["arrival_station"],
                            "Arrival_Airport__c": obj["arrival_country"],
                            "Airline_Code__c": obj["airline_code"],
                            "Flight_Number__c": obj["flight_no"],
                            "Language__c": obj["traveller_language"],
                            "NPS_Survey_Link__c": combinedUrl
                        }]
                    });

                    const smsdata = JSON.stringify({
                        "messages": [{
                            "from": "AIRASIA",
                            "destinations": [{ "to": obj["country_code_contact_no"] + obj["mobile"] }],
                            "text": config.smsService.traveller_language[obj["traveller_language"]] || config.smsService.traveller_language.Default + combinedUrl
                        }],
                        "urlOptions": { "shortenUrl": true }
                    });

                    // Send data to external services based on configuration
                    try {
                        if (config.permissions.isEnable_Push === "true") await sendDataToCleverTap(JSON.stringify(dataToCleverTap));
                        console.log(new Date(), "Push notification sent successfully.");

                        if (config.permissions.isEnable_Email === "true") await emailService(dataToEmail);
                        console.log(new Date(), "Email sent successfully.");

                        //   if (config.permissions.isEnable_Sms === "true") await smsService(smsdata);
                        //   console.log(new Date(), "SMS sent successfully.");
                    } catch (error) {
                        console.error(new Date(), 'Error during data transfer:', error.message);
                    }

                    loopCount++; // Increment row counter for each processed row
                }
            }

            // Move processed file if enabled in configuration
            const newFilePath = `${config.csvReaderFilePath.processedFilePath}/${file.name}`;
            try {
                if (config.permissions.isEnable_Filemoving === "true") {
                    await sftp.put(buffer, newFilePath);
                    console.log(new Date(), `File successfully moved to: ${newFilePath}`);
                    await sftp.delete(remoteFilePath);
                }
            } catch (moveError) {
                await moveFileAndHandleFailure(buffer, remoteFilePath);
                console.error(new Date(), 'Error during file move:', moveError.message);
            }
            // Update processing count
            const { counter = 0, sys_Id } = await fetchCounter();  // Default to 0 if undefined
            const updatecount = loopCount + counter;
            console.log(new Date(), "Current counter:", counter, "Rows processed in this run:", loopCount);
            // Check the condition to either insert or update
            if (counter === 0) {
                console.log("No counter exists for the current date. Inserting new counter...");
                await insertCounter(loopCount); // Insert the new counter
                console.log(new Date(), "Counter inserted with value:", loopCount);
            } else {
                console.log(new Date(), `Updating counter: Current value: ${counter}, Adding: ${loopCount}`);
                await updateCounter(sys_Id, updatecount); // Update the counter
                console.log(new Date(), `Counter updated to: ${updatecount}`);
                // const deleteresponse = await deleteCounter();
                // console.log(new Date(),"Delete",deleteresponse);
                // console.log(new Date(),`insertupdate counter: Current value: ${counter}, Adding: ${updatecount}`);
                // await insertupdateCounter(updatecount);
                // console.log(new Date(),`insertupdatecounter: Current value: ${updatecount}`);

            }

            break;
        }
    } catch (error) {
        console.error(new Date(), 'Error while reading from SFTP:', error.message);
        return null;

    }
}

console.log(new Date(), 'Scheduler is set to run every 30 minutes to read incoming CSV files.');






