const axios = require("axios");
const fs = require("fs");
const schedule = require('node-schedule');
const config = require("./config");
var botName = "NPS Survey UAT";
const Mailer = require('./Mailer.js');
var botId = Object.keys(config.credentials);
module.exports = {
  botId: botId,
  botName: botName,
};

var departmentMapper = [];

const JWT_ACCESS_TOKEN =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1jMjIzN2U0OS00ZDk4LTU2OGMtYWJkOS01YjQzOGNhYzIyYjQifQ.6jOH163uPeKfsYRjYvv0MeWy8mkraFhDEIWliHgqHXY";
const API_URL =
  "https://bots.kore.ai/api/public/bot/st-eb6c9752-1a97-5ea5-b32c-4ff78e4fa3b5/getSessions?containmentType=selfService";

fs.readFile("./PicDeptMappingUAT.json", "utf8", (err, jsonData) => {
  if (err) {
    console.error("Error reading picDeptMapping.json:", err);
    return;
  }
  departmentMapper = JSON.parse(jsonData);
  //  getDetractorSessions();
});
let rule = config.schedular_Time.detractorsSchedule;
console.log(new Date(), 'Scheduler is set to run every 2 hours for Detractors...');
schedule.scheduleJob(rule, async function () {
  console.log(new Date(), "Scheduler Activated: Initiating detractors Sessions...");
  try {
    await getDetractorSessions();
  } catch (error) {
    console.error('An error occurred in the scheduled task:', error);
  }
});
async function getDetractorSessions() {
  const currentTime = new Date();
  const dateTo = currentTime.toISOString();
  const dateFrom = new Date(currentTime.getTime() - 2 * 60 * 60 * 1000).toISOString();

  try {
    const response = await axios.post(
      API_URL,
      {
        skip: 0,
        limit: 100,
        dateFrom: dateFrom,
        dateTo: dateTo
      },
      {
        headers: {
          auth: JWT_ACCESS_TOKEN,
          "Content-Type": "application/json",
        },
      }
    );

    let detractorSessions = [];

    try {
      const sessions = response.data.sessions;
      
      if (sessions && Array.isArray(sessions)) {
        detractorSessions = sessions
          .filter((session) => {
            const scoreCategoryTag = session.tags.sessionTags.find(
              (tag) => tag.name === "score_category"
            );
            const subTag = session.tags.sessionTags.find(
              (tag) => tag.name === "sub_tag"
            )?.value;

            return (
              scoreCategoryTag &&
              scoreCategoryTag.value === "Detractors" &&
              subTag !== undefined &&
              subTag !== null
            );
          })
          .map((session) => {
            const ata = session.tags.sessionTags.find((tag) => tag.name === "ata")?.value || "N/A";
            const flight_no = session.tags.sessionTags.find((tag) => tag.name === "flight_no")?.value || "N/A";
            //const travellerName = session.tags.sessionTags.find((tag) => tag.name === "traveller_name")?.value || "N/A";
            //const email = session.tags.sessionTags.find((tag) => tag.name === "email")?.value || "N/A";
            const score = session.tags.sessionTags.find((tag) => tag.name === "score")?.value || "N/A";
            const touchpoint = session.tags.sessionTags.find(
              (tag) => tag.name === "PJ_touchpoint" || tag.name === "PB_touchpoint"
                )?.value || "N/A";         
            const mainTag = session.tags.sessionTags.find((tag) => tag.name === "main_tag")?.value || "N/A";
            const subTag = session.tags.sessionTags.find((tag) => tag.name === "sub_tag")?.value || "N/A";
            
            //const aoc = session.tags.sessionTags.find((tag) => tag.name === "aoc")?.value || "N/A";
            // const departureCountry = session.tags.sessionTags.find((tag) => tag.name === "departure_country")?.value || "N/A";
            // const departureStation = session.tags.sessionTags.find((tag) => tag.name === "departure_station")?.value || "N/A";
            // const arrivalCountry = session.tags.sessionTags.find((tag) => tag.name === "arrival_country")?.value || "N/A";
            // const arrivalStation = session.tags.sessionTags.find((tag) => tag.name === "arrival_station")?.value || "N/A";
            // const flyThru = session.tags.sessionTags.find((tag) => tag.name === "flythru_flg")?.value || "N/A";
            // const pos = session.tags.sessionTags.find((tag) => tag.name === "pos")?.value || "N/A";
            // const route = session.tags.sessionTags.find((tag) => tag.name === "route")?.value || "N/A";
            const pnr = session.tags.sessionTags.find((tag) => tag.name === "pnr")?.value || "N/A";
            //const mobile = session.tags.sessionTags.find((tag) => tag.name === "mobile")?.value || "N/A";
            const interactiveLanguage = session.tags.sessionTags.find((tag) => tag.name === "interactiveLanguage")?.value || "N/A";
            const scoreCategory = session.tags.sessionTags.find((tag) => tag.name === "score_category")?.value || "N/A";
            return {
              ata,
              flight_no,
              // travellerName,
              // email,
              score,
              mainTag,
              subTag,
              touchpoint,
              // aoc,
              // departureCountry,
              // departureStation,
              // arrivalCountry,
              // arrivalStation,
              // flyThru,
              // pos,
              // route,
              pnr,
              // mobile,
              interactiveLanguage,
              scoreCategory,
            };
          });
      } else {
        console.log(new Date(),"No sessions data available");
      }
    } catch (error) {
      console.error("Error processing sessions:", error);
    }
    

    let emailObjects = [];
    let dataTable = [];
    //const uniqueEmailRecords = new Set(); // To store unique email entries

    detractorSessions.forEach((session) => {
      
      const interactiveLanguageMapping = departmentMapper[session.interactiveLanguage];
      if (interactiveLanguageMapping) {
        const touchpointMapping = interactiveLanguageMapping[session.touchpoint];

        if (touchpointMapping) {
          try {
            // Parse the subTag JSON from session
            const subTagString = session.subTag;
            if (!subTagString) {
              console.warn("subTag is undefined or empty for session:", session);
              return; // Skip this iteration if subTag is not valid
            }
            const subTagJson = JSON.parse(session.subTag);

            // Iterate through each mainTag and subTags in the subtagJson
            subTagJson.forEach((tagObject) => {
              const mainTag = tagObject.maintag; // Extract mainTag
              const mainTagMapping = touchpointMapping[mainTag]; // Get main tag mapping

              if (mainTagMapping) {
                // Iterate through each subtag in subtags
                tagObject.subtags.forEach((subtag) => {
                  const subTagName = subtag.name;
                  //console.log(subtag);
                  const departments = subtag.department?subtag.department.split(",").map((dep) => dep.trim()):[]; // Get all departments
                  departments.forEach((dep) => {
                    const picEmails = mainTagMapping[subTagName]?.[dep]; // Safely access nested mappings

                    if (picEmails) {
                      const emailList = picEmails.split(",").map((email) => email.trim()); // Split emails into a list


                      const dataRecord = {
                        // remarks: "N/A",
                        // actionItem: "N/A",
                        // completionDate: "N/A",
                        // status: "N/A",
                        score: session.score,
                        // travellerName: session.travellerName,
                        // email: session.email,
                        assignedDate : new Date().toLocaleDateString('en-GB').split('/').reverse().join('-'),
                        mainTag,
                        subTag: subTagName,
                        //touchpoint: session.touchpoint,
                        //department: dep,
                        mainTagComment: tagObject.comments || "No comment provided",
                        //subTagRating: subtag.rating || "No rating provided",
                        // aoc: session.aoc,
                        // departureCountry: session.departureCountry,
                        // departureStation: session.departureStation,
                        // arrivalCountry: session.arrivalCountry,
                        // arrivalStation: session.arrivalStation,
                        // flyThru: session.flyThru,
                        // pos: session.pos,
                        // route: session.route,
                        pnr: session.pnr,
                        flight_no: session.flight_no,
                        // mobile: session.mobile,
                        // travellerLanguage: session.travellerLanguage,
                        // scoreCategory: session.scoreCategory,
                        ata: session.ata
                      };

                      // Assign the emails to the correct fields dynamically
                      emailList.forEach((email, index) => {
                        dataRecord[`PIC_${index + 1}_email`] = email || "N/A";
                      });

                      // Ensure all 4 email fields are available (fill missing with N/A)
                      for (let i = emailList.length; i < 4; i++) {
                        dataRecord[`PIC_${i + 1}_email`] = "N/A";
                      }

                      // Push the data record into the dataTable
                      dataTable.push(dataRecord);

                      // Add each email as an object in the emailObjects array
                      emailList.forEach((email) => {
                        if (!emailObjects.some(obj => obj.pic === email)) { // Ensure uniqueness
                          emailObjects.push({
                            pic: email,
                          });
                        }
                      });
                    }
                  });
                });
              }
            });

          } catch (error) {
            console.error("Failed to parse subTag JSON or access PIC emails:", error);
          }
        }
      }
    });

   // console.log(new Date(), 'Email objects:', emailObjects);
 //   console.log(new Date(), "Data records:", dataTable);

     dataTable.forEach((record) => insertDetractorInfo(record));

    async function insertDetractorInfo(record) {
      const dataPayload = {
        data: {
          ...record,
        }
      };
      try {
        const response = await axios.post(
          "https://bots.kore.ai/api/public/tables/DetractorsInfo_UAT",
          dataPayload,
          {
            headers: {
              "Content-Type": "application/json",
              auth: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy02ZTJjYjhlNi0xYWNjLTU0MDAtODIyMi04MzBlZWMwN2RkYmYifQ.t4IbFTZZqQZJef5HNLp_lDqKbOTjBkzzxfoLJ7i1uA8",
            },
          }
        );
        console.log(new Date(), "Row inserted with pnr:", response.data.pnr);
      } catch (error) {
        console.error("Error inserting row:", error);
      }
    }

    const filteredEmailObjects = emailObjects.filter((obj, index, self) =>
      index === self.findIndex((t) => t.pic === obj.pic)
    );

    if (filteredEmailObjects.length > 0) {
      const emailsToSend = filteredEmailObjects.map(obj => obj.pic);
        emailsToSend.forEach(mail => Mailer.useNodemailer(mail));
      console.log(new Date(), `Sent ${emailsToSend.length} emails to:`, emailsToSend.join(", "));
    } else {
      console.log(new Date(), "No emails found.");
    }


    //console.log(new Date(),"Filtered Email records:", filteredEmailObjects);
  } catch (error) {
    console.error("Error retrieving sessions:", error);
  }
}

