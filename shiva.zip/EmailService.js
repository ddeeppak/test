const axios = require('axios');
//const api = require("./api");
const config = require("./config");
const tokenUrl = config.api.tokenCreation_api;
const params = new URLSearchParams({
    username: config.salesforce.username,
    password: config.salesforce.password,
    grant_type: config.salesforce.grant_type,
    client_id: config.salesforce.client_id,
    client_secret: config.salesforce.client_secret
});

async function generateToken() {
    try {
        const response = await axios.post(tokenUrl, params.toString(), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
                
            },
        });
        return response.data.access_token;
    } catch (error) {
        console.error('Error generating token:', error.response ? error.response.data : error.message);
      
    }
}

async function sendDataToSalesforce(token, dataToEmail) {
    const url = config.api.email_api;
    const data = dataToEmail;
    
    try {
        let emailapi = {
            method: 'post',
            // maxBodyLength: Infinity,
            url: url,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
                 },
            data: data
        };
       // console.log("email api",emailapi)
        await axios.request(emailapi).then((response) => {
          //  console.log(new Date(),"Email sent sucessfully...")
          })
        

    }
    catch (error) {
        if (error.response) {
            console.error('Error sending data to Salesforce:', {
                status: error.response.status,
                data: error.response.data,
                headers: error.response.headers
            });
        } else {
            console.error('Error message:', error.message);
        }
    }
}


async function emailService(dataToEmail) {
    try {
        const token = await generateToken();
        await sendDataToSalesforce(token, dataToEmail);
        const smsDataObject = JSON.parse(dataToEmail);
const emailAddress = smsDataObject.records[0].Email_Address__c;
console.log(new Date(), `Email sent to: ${emailAddress}`);

    } catch (error) {
        console.error('Error in process:', error.message);
    }
}


module.exports = emailService;


