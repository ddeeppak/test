const nodemailer = require('nodemailer');
const config = require('./config.json');

async function sendMailWithBufferAttachment(toEmail, subject, text, htmlContent, fileBuffer, fileName) {
  try {   
    let transporter = nodemailer.createTransport({
      host: config.email.host,
      port: config.email.port,
      secure: false, 
      auth: {
        user: config.email.user,
        pass: config.email.pass, 
      },
    });
   
    let mailOptions = {
      from: `"AirAsia Backup Service" <${config.email.user}>`, 
      to: toEmail, 
      subject : subject, 
      text : text,
      htmlContent : htmlContent,

      attachments: [
        {
          filename: fileName, 
          content: fileBuffer,
        },
      ],
    };

   
    let info = await transporter.sendMail(mailOptions);
    console.log(new Date(), "Email sent successfully",info.messageId);

    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.log(new Date(), "Error sending email",error);

    return { success: false, error };
  }
}

async function moveFileAndHandleFailure( buffer, remoteFilePath) {   
   
    const fileName = remoteFilePath.split('/').pop(); 
    const toEmail = config.email.toMail; 
    const subject = config.email.subject;
    const text = `The file ${fileName} failed to move to the backup location.`;
    const htmlContent = `<p>The file <strong>${fileName}</strong> failed to move to the backup location.</p>`;   
    const result = await sendMailWithBufferAttachment(toEmail, subject, text, htmlContent, buffer, fileName);

    if (!result.success) {
      console.log(new Date(), "Failed to send email for backup file",result.error);
    }
  
}

module.exports = {
  moveFileAndHandleFailure,
};
