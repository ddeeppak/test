const nodemailer = require('nodemailer');
const config = require('./config.json');

const transporter = nodemailer.createTransport({
  // service: 'gmail',
  host: config.detractors_email.host,
  port: config.detractors_email.port,
  secure: false,
  auth: {
    user: config.detractors_email.user,
    pass: config.detractors_email.pass,
  }
});

const useNodemailer = async (email) => {
  const mailOptions = {
    from: `"Air Asia" <${config.detractors_email.user}>`,
    to: email,
    subject: config.detractors_email.subject,
    html: `
         ${config.detractors_email.html_content1}
      
          <p><a href="https://us-central1-prathamesh01.cloudfunctions.net/AirAsia_Web_Bot/UI/index_minified.html?touchPoint=pic&interactiveLanguage=en&email=${email}">Click Here</a></p>
      
          ${config.detractors_email.html_content2}
        `
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(new Date(), `Email sent: ${info.response} to ${email}`);
  } catch (error) {
    console.error('Error sending email:', error);
  }
}


module.exports = {
  useNodemailer

}
