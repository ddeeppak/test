const axios = require('axios');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const schedule = require('node-schedule');
const fs = require('fs');
const Client = require('ssh2-sftp-client');
const config = require("./config");
var botName = "NPS Survey";
var botId = Object.keys(config.credentials);
const { moveFileAndHandleFailure } = require('./FileBackupFailureMailer.js');


const JWT_ACCESS_TOKEN = config.outgoingCsv.jwtToken;
const API_URL = config.outgoingCsv.api_url;
//const BOT_ID = 'st-2ce70342-d0a3-5849-913b-b83cbc77cb9d';

const SFTP_HOST = config.sftp.host; // SFTP server host
const SFTP_PORT = config.sftp.port; // Default port for SFTP
const SFTP_USERNAME = config.sftp.username; // Your SFTP username
const SFTP_PASSWORD = config.sftp.password; // Your SFTP password
const REMOTE_FILE_PATH = config.outgoingCsv.outgoingFilePath; // Remote path where the file will be uploaded

module.exports = {
  botId: botId,
  botName: botName,
};

// Function to fetch all sessions and process the data
async function getAllSessions() {
  let allSessions = [];
  let skip = 0;
  const limit = 10;
  let moreAvailable = true;
  const currentTime = new Date();
  const dateTo = currentTime.toISOString();
  const dateFrom = new Date(currentTime.getTime() - 2 * 60 * 60 * 1000).toISOString();


  try {
    while (moreAvailable) {
      const response = await axios.post(
        `${API_URL}`,
        {
          skip,
          limit,
          dateFrom: dateFrom,
          dateTo: dateTo
        },
        {
          headers: {
            'auth': JWT_ACCESS_TOKEN,
            'Content-Type': 'application/json'
          }
        }
      );

      const sessions = response.data.sessions;
      moreAvailable = response.data.moreAvailable;

      allSessions = allSessions.concat(sessions);

      skip += limit;
    }

    const sessionDetails = allSessions.map(session => {
      const tags = session.tags.sessionTags;

      const getTagValue = (tagName) => {
        return tags.find(tag => tag.name === tagName)?.value || 'N/A';
      };

      const ata = getTagValue('ata');
      const aoc = getTagValue('aoc');
      const departureCountry = getTagValue('departure_country');
      const departureStation = getTagValue('departure_station');
      const arrivalCountry = getTagValue('arrival_country');
      const arrivalStation = getTagValue('arrival_station');
      const flyThru = getTagValue('flythru_flg');
      const pos = getTagValue('pos');
      const route = getTagValue('route');
      const pax_count = getTagValue('pax_count');
      const pnr = getTagValue('pnr');
      const travellerName = getTagValue('traveller_name');
      const email = getTagValue('email');
      const country_code_contact_no = getTagValue('country_code_contact_no');
      const mobile = getTagValue('mobile');
      const travellerLanguage = getTagValue('traveller_language');
      const fare_type = getTagValue('fare_type');
      const flight_no = getTagValue('flight_no');
      const airline_code = getTagValue('airline_code');
      const aircraft_type = getTagValue('aircraft_type');
      const aircraft_reg_no = getTagValue('aircraft_reg_no');
      const score = getTagValue('score');
      const mainTag = getTagValue('main_tag');
      const subTag = getTagValue('sub_tag');
      const feedback = getTagValue('feedback');
      const scoreCategory = getTagValue('score_category');
      const department = getTagValue('department');
      const touchpoint = getTagValue('touchpoint');


      return {
        ata,
        aoc,
        departureCountry,
        departureStation,
        arrivalCountry,
        arrivalStation,
        flyThru,
        pos,
        route,
        pnr,
        travellerName,
        email,
        mobile,
        travellerLanguage,
        score,
        mainTag,
        subTag,
        feedback,
        scoreCategory,
        pax_count,
        country_code_contact_no,
        fare_type,
        flight_no,
        airline_code,
        aircraft_type,
        aircraft_reg_no,
        department,
        touchpoint

      };
    });

    await writeDataToCSV(sessionDetails);

    // Upload CSV to SFTP after generating it
    await uploadToSFTP('outgoing.csv', REMOTE_FILE_PATH);

    console.log(new Date(), "Sessions data has been successfully written to outgoing.csv and uploaded to SFTP");
  } catch (error) {
    console.error('Error fetching sessions or uploading to SFTP:', error);
  }
}

// Function to write session data to CSV
async function writeDataToCSV(data) {
  const csvWriter = createCsvWriter({
    path: 'outgoing.csv',
    header: [
      { id: 'ata', title: 'ata' },
      { id: 'aoc', title: 'aoc' },
      { id: 'departureCountry', title: 'departure_country' },
      { id: 'departureStation', title: 'departure_station' },
      { id: 'arrivalCountry', title: 'arrival_country' },
      { id: 'arrivalStation', title: 'arrival_station' },
      { id: 'flyThru', title: 'flythru_flg' },
      { id: 'pos', title: 'pos' },
      { id: 'route', title: 'route' },
      { id: 'pax_count', title: 'pax_count' },
      { id: 'pnr', title: 'pnr' },
      { id: 'travellerName', title: 'traveller_name' },
      { id: 'email', title: 'email' },
      { id: 'country_code_contact_no', title: 'country_code_contact_no' },
      { id: 'mobile', title: 'mobile' },
      { id: 'traveller_language', title: 'traveller_language' },
      { id: 'fare_type', title: 'fare_type' },
      { id: 'flight_no', title: 'flight_no' },
      { id: 'airline_code', title: 'airline_code' },
      { id: 'aircraft_type', title: 'aircraft_type' },
      { id: 'aircraft_reg_no', title: 'aircraft_reg_no' },

      { id: 'mainTag', title: 'main_tag' },
      { id: 'subTag', title: 'sub_tag' },
      { id: 'score', title: 'score' },
      { id: 'scoreCategory', title: 'score_category' },
      { id: 'touchpoint', title: 'touchpoint' },
      { id: 'feedback', title: 'feedback' },
      // { id: 'department', title: 'department' }
    ]
  });
  data = data.filter(row => {
    return !Object.values(row).every(value => value === "N/A" || value === null || value === undefined || Number.isNaN(value));
  });
  await csvWriter.writeRecords(data);
}

// Function to upload file to SFTP server
async function uploadToSFTP(localFilePath, remoteFilePath) {
  const sftp = new Client();

  const config = {
    host: SFTP_HOST,
    port: SFTP_PORT,
    username: SFTP_USERNAME,
    password: SFTP_PASSWORD,

    algorithms: {
            serverHostKey: ['ssh-dss', 'ssh-rsa'],
            kex: [
                'diffie-hellman-group-exchange-sha256',
                'diffie-hellman-group14-sha1',
                'diffie-hellman-group1-sha1'
            ],
            cipher: [
                'aes128-ctr', 'aes192-ctr', 'aes256-ctr',
                'aes128-gcm', 'aes256-gcm'
            ],
            serverHostKey: [ 'ssh-rsa', 'ssh-dss' ]
        }
  };

  try {
    await sftp.connect(config);
    await sftp.put(localFilePath, remoteFilePath);
    fs.unlinkSync(localFilePath);
    console.log(new Date(), `File uploaded to SFTP server at: ${remoteFilePath}`);
  } catch (err) {
    // Try to move file and handle failure if needed                     
    try {
      const buffer = fs.readFileSync(localFilePath);
      await moveFileAndHandleFailure(buffer, remoteFilePath);
    } catch (readErr) {
      console.error('Error reading the local CSV file for backup handling:', readErr);
    }
    console.error('Error uploading file to SFTP:', err);
  } finally {
    sftp.end();
  }
}

let rule = config.schedular_Time.outgoingCsvSchedule;

schedule.scheduleJob(rule, function () {
  console.log(new Date(), 'Scheduler triggered from Outgoing: Fetching sessions, writing data to CSV, and uploading to SFTP.');
  try {
    getAllSessions();
  } catch (error) {
    console.error('An error occurred in the scheduled task:', error);
  }
});

console.log(new Date(), 'Scheduler is set to run every 2 hours for Outgoing CSV file.');
