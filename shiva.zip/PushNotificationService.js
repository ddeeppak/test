const config = require("./config");
//const api = require("./api");
const axios = require('axios');

async function sendDataToCleverTap(data) {
    const url = config.api.pushnotification_api;

    const axiosConfig = {
        headers: {
            'X-CleverTap-Account-Id': config.clevertap.account_ID,
            'X-CleverTap-Passcode': config.clevertap.passcode,
            'Content-Type': config.clevertap.content_Type
        }
    };

    try {
       // console.log(new Date(), "Push notification process initiated.");       
        const response = await axios.post(url, data, axiosConfig);
       // console.log(new Date(), "Data successfully sent.");
    } catch (error) {
        console.error('Error sending data:', error.message);
        if (error.response) {
            console.error('Error details:', error.response.data);
        }
    }
}

module.exports = sendDataToCleverTap;
