const axios = require('axios');
const config = require("./config");

async function smsService(smsdata) {
    try {
       
        await sendSms(smsdata);
    } catch (error) {
        console.error('Error in process:', error.message);
    }
}

async function sendSms(smsdata) {
  console.log(new Date(), "SMS sending process initiated.");
  const smsDataObject = JSON.parse(smsdata);
const mobileNumber = smsDataObject.messages[0].destinations[0].to;
//console.log(new Date(), `SMS successfully sent to mobile number: ${mobileNumber}`);

  
    const url = config.api.sms_api;
    let smsapicall = {
        method: 'post',        
        url: url,
        headers: { 
          'Content-Type': config.smsService.content_Type, 
          'Authorization': config.smsService.authorization
        },
        data : smsdata
      };
      
      axios.request(smsapicall)
      .then(() => {
        //console.log(new Date(),"Sms sent sucessfully...");
      })
      .catch((error) => {
        console.log(new Date(),error.message);
      });
}
module.exports = smsService;