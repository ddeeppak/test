// Import the Google Cloud Functions framework for deploying the function
const functions = require('@google-cloud/functions-framework');

// Import Axios for making HTTP requests from within the Cloud Function
const axios = require('axios');

// Import necessary modules for setting up the Botkit server and bot logic
var Application = require("./lib/app/index.js"); // Main application setup file
var Server = require("./lib/server/index.js"); // Server setup file
var sdk = require("./lib/sdk/index.js"); // SDK providing bot development utilities
var config = require("./config"); // Configuration file containing app settings

console.log(new Date(),"Starting application setup...");

var app = new Application(null, config);
var server = new Server(config, app);

sdk.checkNodeVersion();

// Start the server to listen for incoming requests
server.start();
console.log(new Date(),"Server has started and is listening for requests");

sdk.registerBot(require('./AirAsiaBot.js'));
console.log(new Date(),"AirAsia bot registered successfully");

// Define the Cloud Function entry point for handling HTTP requests
functions.http('Botkit', async (req, res) => {
    try {
        // Log the incoming request details
        console.log(new Date(),"Received HTTP request:", {
            method: req.method,
            path: req.path,
            headers: req.headers,
            body: req.body
        });

        // Forward the incoming request to the local server listening on port 8003
        await axios({
            method: req.method,
            url: `http://localhost:8003${req.path}`, // Forward to the locally running Botkit app
            data: req.body,
            headers: {
                ...req.headers,
                host: 'localhost:8003', // Setting the host header to avoid CORS issues in local environment
            },
        });

        // Log successful forwarding
        console.log(new Date(),"Request forwarded to local server on port 8003");
    } catch (error) {
        // Log the error if the forwarding fails, without sending a response back
        console.error('Error in BotKit function:', error);
    }
});
